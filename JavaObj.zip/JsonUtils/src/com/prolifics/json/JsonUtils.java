package com.prolifics.json;

import com.prolifics.jni.Application;
import com.prolifics.jni.ApplicationInterface;
import com.prolifics.jni.CFunctionsInterface;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import org.json.JSONArray;
import org.json.JSONObject;

public class JsonUtils  {
	ApplicationInterface ai = Application.getInstance();
	CFunctionsInterface cf = ai.getCFunctions();

	private static final Logger LOGGER = Logger.getLogger(JsonUtils.class.getName());
	
	FileHandler fh;
	
	private final String USER_AGENT = "Mozilla/5.0";
	// HTTP GET request
		public String sendGet(String url) throws Exception {
			
			fh = new FileHandler("C:/logger/MyFile.log"); //Location for your log file
			LOGGER.addHandler(fh);
			SimpleFormatter formatter = new SimpleFormatter();
			fh.setFormatter(formatter);
			
			LOGGER.info("URL" + url);
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			// optional default is GET
			con.setRequestMethod("GET");

			//add request header
			con.setRequestProperty("User-Agent", USER_AGENT);
			con.setRequestProperty("Content-Type", "application/json");
			int responseCode = con.getResponseCode();
			System.out.println("\nSending 'GET' request to URL : " + url);
			System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(
			        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
		
		    String str = response.toString();
			
			JSONObject jsonObj = new JSONObject(new String(str));
			String strval = getPostDataString(jsonObj);
			return String.valueOf(responseCode);
		}
		
		//The below method takes the JSON response and loops through the key and value pairs so that we get the
		//key and values sorted into the panther widgets based on the occurrence numbers as well
		
		public String getPostDataString(JSONObject params) throws Exception 
		{
			StringBuilder builder = new StringBuilder();
			getPostDataString("", params, builder, 1);
			return builder.toString();
		}
		
		public String getPostDataString(String name, Object value, StringBuilder builder, int index) throws Exception 
		{
			if (value instanceof JSONObject) {
				JSONObject params = (JSONObject)value;
				String key = null;
				Object val = null;
			
				Iterator<String> itr = params.keys();

				while (itr.hasNext()) {
					key = itr.next();
					val = params.get(key);
					if (val != null) {
						getPostDataString(key, val, builder, index);
					}
				}
			} else if (value instanceof JSONArray) {
				JSONArray jsonArray = (JSONArray)value;
				Object o;
				Class clazz = null;
				
				for (int i = 0; i < jsonArray.length(); i++) {		
					o = jsonArray.get(i);
					if (i == 0) {
						clazz = o.getClass();
					}
					// For our purposes, arrays should contain the same type of thing
					if (o != null && clazz.isInstance(o)) {
						getPostDataString(name, o, builder, i+1);
					}
				}
			} else {
				
				LOGGER.info(index+" "+name+" = "+value.toString());
				cf.sm_i_putfield(name,index ,value.toString());
			}
			
			return builder.toString();
		}
}
