import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Formatter;
import java.util.logging.SimpleFormatter;
import java.util.logging.Handler;
import com.prolifics.jni.FieldInterface;
import com.prolifics.jni.Application;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import com.prolifics.jni.CFunctionsInterface;
import com.prolifics.jni.ApplicationInterface;
import com.prolifics.jni.ButtonHandlerAdapter;

// 
// Decompiled by Procyon v0.5.36
// 

public class TestGet extends ButtonHandlerAdapter
{
    ApplicationInterface ai;
    CFunctionsInterface cf;
    private static final Logger LOGGER;
    FileHandler fh;
    private final String USER_AGENT = "Mozilla/5.0";
    
    static {
        LOGGER = Logger.getLogger(TestGet.class.getName());
    }
    
    public TestGet() {
        this.ai = Application.getInstance();
        this.cf = this.ai.getCFunctions();
    }
    
    public int buttonActivate(final FieldInterface fi, final int item) {
        final CFunctionsInterface c = fi.getCFunctions();
        final String url = c.sm_n_fptr("url");
        try {
            this.sendGet(url);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return item;
    }
    
    public String sendGet(final String url) throws Exception {
        this.fh = new FileHandler("C:/logger/MyFile.log");
        TestGet.LOGGER.addHandler(this.fh);
        final SimpleFormatter formatter = new SimpleFormatter();
        this.fh.setFormatter(formatter);
        TestGet.LOGGER.info("URL" + url);
        final URL obj = new URL(url);
        final HttpURLConnection con = (HttpURLConnection)obj.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        con.setRequestProperty("Content-Type", "application/json");
        final int responseCode = con.getResponseCode();
        TestGet.LOGGER.info("\nSending 'GET' request to URL : " + url);
        TestGet.LOGGER.info("Response Code : " + responseCode);
        final BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        final StringBuffer response = new StringBuffer();
        TestGet.LOGGER.info("RESPONSE" + (Object)response);
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        final String str = response.toString();
        TestGet.LOGGER.info("STR" + str);
        final JSONObject jsonObj = new JSONObject(new String(str));
        final String strval = this.getPostDataString(jsonObj);
        return String.valueOf(responseCode);
    }
    
    public String getPostDataString(final JSONObject params) throws Exception {
        final StringBuilder builder = new StringBuilder();
        this.getPostDataString("", params, builder, 1);
        return builder.toString();
    }
    
    public String getPostDataString(final String name, final Object value, final StringBuilder builder, final int index) throws Exception {
        if (value instanceof JSONObject) {
            final JSONObject params = (JSONObject)value;
            String key = null;
            Object val = null;
            final Iterator<String> itr = (Iterator<String>)params.keys();
            while (itr.hasNext()) {
                key = itr.next();
                val = params.get(key);
                if (val != null) {
                    this.getPostDataString(key, val, builder, index);
                }
            }
        }
        else if (value instanceof JSONArray) {
            final JSONArray jsonArray = (JSONArray)value;
            Class clazz = null;
            for (int i = 0; i < jsonArray.length(); ++i) {
                final Object o = jsonArray.get(i);
                if (i == 0) {
                    clazz = o.getClass();
                }
                if (o != null && clazz.isInstance(o)) {
                    this.getPostDataString(name, o, builder, i + 1);
                }
            }
        }
        else {
            TestGet.LOGGER.info(String.valueOf(index) + " " + name + " = " + value.toString());
            this.cf.sm_i_putfield(name, index, value.toString());
        }
        return builder.toString();
    }
}