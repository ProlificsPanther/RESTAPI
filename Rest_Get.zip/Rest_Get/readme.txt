1. copy the TestGet.class file to your classpath
2. Add the screen(Test) to your library
3. Run the screen in the Test Mode, enter the time zone (example : est,pst)
4. To set the time zone into your URL click on the set button (Note: Tabbing out after entering the time zone will also set the time zone automatically)
5. You will see the msg of your URL once it is set correctly
6 Click the call button(which will talk to your class file), you will now see that the values are filled out into the text fields on your screen

Note : 	1. we are using java tag property on the call push button (identity->javatag->TestGet)
	2. Make sure you have pro5,java-json jars pointed in your class path