import com.prolifics.jni.*;

public class Test extends ButtonHandlerAdapter
{

public int buttonValidate(FieldInterface f, int item, int context)
{

CFunctionsInterface c = f.getCFunctions();
		c.sm_n_putfield("myfld", "Hello World");

return 0;
}
}